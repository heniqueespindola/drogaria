package com.akangatur.domain;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@SuppressWarnings("serial")
@Entity
public class ViagemPacote extends GenericDomain {

	@Column(length = 80, nullable = false)
	private String descricao;


	@Column(nullable = false, precision = 6, scale = 2)
	private BigDecimal preco;

	@ManyToOne
	@JoinColumn(nullable = false)
	private Provedor provedor;

	public Provedor getProvedor() {
		return this.provedor;
	}

	public BigDecimal getPreco() {
		return this.preco;
	}

	public String getDescricao() {
		return this.descricao;
	}

	public void setDescricao(final String descricao) {
		this.descricao = descricao;
	}

	public void setProvedor(final Provedor provedor) {
		this.provedor = provedor;
	}

	public void setPreco(final BigDecimal preco) {
		this.preco = preco;
	}

	
}
