package com.akangatur.bean;
import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.akangatur.dao.EstadoDAO;
import com.akangatur.domain.Estado;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class EstadoBean implements Serializable{
	private Estado estado;
	private List<Estado> estados;
	
	public Estado getEstado() {
		return estado;
	}
	
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
	
	
	public List<Estado> getEstados() {
		return estados;
	}

	public void setEstados(List<Estado> estados) {
		this.estados = estados;
	}
	
	@PostConstruct // ele é criado na hora que o bean for instanciado
	public void listar(){
		try{
			EstadoDAO estadoDAO = new EstadoDAO();
			estados = estadoDAO.listar();
			
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Aconteceu um erro ao tentar listar Estados");
			erro.printStackTrace();
		}
	}
	
	public void novo(){
		estado = new Estado();
	}
	
	public void salvar(){
		try {
			
		
			EstadoDAO estadoDAO = new EstadoDAO();
			estadoDAO.merge(estado);
		
			novo();
			estados = estadoDAO.listar();
		
			Messages.addGlobalInfo("Estado "+ estado.getNome()+ " salvo com sucesso");
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Aconteceu um erro ao tentar salvar Estado");
			erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		estado = (Estado) evento.getComponent().getAttributes().get("estadoSelecionado");

		try{
			EstadoDAO estadoDAO = new EstadoDAO();
			estadoDAO.excluir(estado);
			
			novo();
			estadoDAO.listar();
			
			Messages.addGlobalInfo("Estado "+ estado.getNome()+ " excluido com sucesso");
		}catch(RuntimeException erro){
			Messages.addGlobalError("Aconteceu um erro ao tentar excluir Estado");
			erro.printStackTrace();
		}
	}

	public void editar(ActionEvent evento){
		estado = (Estado) evento.getComponent().getAttributes().get("estadoSelecionado");
		
	}
	
}
