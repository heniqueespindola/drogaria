package com.akangatur.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.akangatur.dao.ProvedorDAO;
import com.akangatur.dao.ViagemPacoteDAO;
import com.akangatur.domain.Provedor;
import com.akangatur.domain.ViagemPacote;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped

public class ViagemPacoteBean implements Serializable{
	ViagemPacote viagemPacote;
	List<ViagemPacote> viagemPacotes;
	List<Provedor> provedores;
	
	public ViagemPacote getviagemPacote() {
		return viagemPacote;
	}
	public void setviagemPacote(ViagemPacote viagemPacote) {
		this.viagemPacote = viagemPacote;
	}
	
	public List<ViagemPacote> getviagemPacotes() {
		return viagemPacotes;
	}
	public void setviagemPacotes(List<ViagemPacote> viagemPacotes) {
		this.viagemPacotes = viagemPacotes;
	}
	
	public void novo(){
		try{
			viagemPacote = new ViagemPacote();
			
			ProvedorDAO provedorDAO = new ProvedorDAO();
			provedores = provedorDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar inicializar viagemPacote");
			erro.printStackTrace();
		}
	}
	
	@PostConstruct
	public void listar(){
		try{
			ViagemPacoteDAO viagemPacoteDAO = new ViagemPacoteDAO();
			viagemPacotes = viagemPacoteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar listar viagemPacote");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try{
			ViagemPacoteDAO viagemPacoteDAO = new ViagemPacoteDAO();
			viagemPacoteDAO.merge(viagemPacote);
			
			novo();
			viagemPacotes = viagemPacoteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar salvar viagemPacote");
			erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		viagemPacote = (ViagemPacote) evento.getComponent().getAttributes().get("viagemPacoteSelecionado");
		try{
			ViagemPacoteDAO viagemPacoteDAO = new ViagemPacoteDAO();
			viagemPacoteDAO.excluir(viagemPacote);
			
			novo();
			viagemPacotes = viagemPacoteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar excluir viagemPacotes");
			erro.printStackTrace();
		}
	}
	
	public void editar(ActionEvent evento){
		try{
			viagemPacote = (ViagemPacote) evento.getComponent().getAttributes().get("viagemPacoteSelecionado");
			
			ProvedorDAO provedorDAO = new ProvedorDAO();
			provedores = provedorDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar editar viagemPacote");
			erro.printStackTrace();
		}
	}

}

