package com.akangatur.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.akangatur.dao.ProvedorDAO;
import com.akangatur.domain.Provedor;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class ProvedorBean implements Serializable{
	private Provedor provedor;
	private List<Provedor> provedores;

	public Provedor getProvedor() {
		return provedor;
	}

	public void setProvedor(Provedor provedor) {
		this.provedor = provedor;
	}

	public List<Provedor> getProvedores() {
		return provedores;
	}

	public void setProvedores(List<Provedor> provedores) {
		this.provedores = provedores;
	}
	
	
	public void novo(){
		provedor = new Provedor();
	}
	
	@PostConstruct
	public void listar(){
		try{
			ProvedorDAO provedorDAO = new ProvedorDAO();
			provedores = provedorDAO.listar();
			
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Aconteceu um erro ao inicializar provedores");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try {
			
			ProvedorDAO provedorDAO = new ProvedorDAO();
			provedorDAO.merge(provedor);
					
			novo();
			provedores = provedorDAO.listar();
		
			Messages.addGlobalInfo("provedor "+ provedor.getDescricao()+ " salvo com sucesso");
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Aconteceu um erro ao tentar salvar provedor");
			erro.printStackTrace();
		}
	} 
	
	public void excluir(ActionEvent evento){
		provedor = (Provedor) evento.getComponent().getAttributes().get("selecionaProvedor");
		
		try {
			
			ProvedorDAO provedorDAO = new ProvedorDAO();
			provedorDAO.excluir(provedor);
					
			novo();
			provedores = provedorDAO.listar();
		
			Messages.addGlobalInfo("provedor "+ provedor.getDescricao()+ " excluido com sucesso");
		} catch (RuntimeException erro) {
			Messages.addGlobalError("Aconteceu um erro ao tentar excluir provedor");
			erro.printStackTrace();
		}
	}
	
	public void editar(ActionEvent evento){
		provedor = (Provedor) evento.getComponent().getAttributes().get("selecionaprovedor");	
	}
}

