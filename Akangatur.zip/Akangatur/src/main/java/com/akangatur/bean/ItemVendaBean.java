package com.akangatur.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.akangatur.dao.FuncionarioDAO;
import com.akangatur.dao.ItemVendaDAO;
import com.akangatur.dao.ViagemPacoteDAO;
import com.akangatur.domain.Funcionario;
import com.akangatur.domain.ItemVenda;
import com.akangatur.domain.ViagemPacote;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class ItemVendaBean implements Serializable{
	ItemVenda itemVenda;
	List<ItemVenda> itemVendas;
	List<Funcionario> funcionarios;
	List<ViagemPacote> viagemPacotes;
	
	public ItemVenda getItemVenda() {
		return itemVenda;
	}
	public void setItemVenda(ItemVenda itemVenda) {
		this.itemVenda = itemVenda;
	}
	
	public List<ItemVenda> getItemVendas() {
		return itemVendas;
	}
	public void setItemVendas(List<ItemVenda> itemVendas) {
		this.itemVendas = itemVendas;
	}
	
	public void novo(){
		try{
			
			itemVenda = new ItemVenda();
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			ViagemPacoteDAO viagemPacoteDAO = new ViagemPacoteDAO();
			
			funcionarios = funcionarioDAO.listar();
			viagemPacotes = viagemPacoteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao inicializar ItemVenda");
			erro.printStackTrace();
		}
	}
	
	@PostConstruct
	public void listar(){
		try{
			ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
			itemVendas = itemVendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar listar ItemVenda");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try{
			ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
			itemVendaDAO.merge(itemVenda);
			
			novo();
			itemVendas = itemVendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar salvar ItemVenda");
			erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		itemVenda = (ItemVenda) evento.getComponent().getAttributes().get("itemVendaSelecionado");
		
		try{
			ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
			itemVendaDAO.excluir(itemVenda);
			
			novo();
			itemVendas = itemVendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar excluir ItemVenda");
			erro.printStackTrace();
		}
	}
	
	public void editar(ActionEvent evento){
		
		try{
			
			itemVenda = (ItemVenda) evento.getComponent().getAttributes().get("Erro ao tentar editar ItemVenda");
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			ViagemPacoteDAO viagemPacoteDAO = new ViagemPacoteDAO();
			
			funcionarios = funcionarioDAO.listar();
			viagemPacotes = viagemPacoteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao editar ItemVenda");
			erro.printStackTrace();
		}
	}
	
	
}
