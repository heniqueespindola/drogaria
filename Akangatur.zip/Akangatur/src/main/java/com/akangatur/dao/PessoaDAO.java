package com.akangatur.dao;

import com.akangatur.domain.Pessoa;

public class PessoaDAO extends GenericDAO<Pessoa> {

}
