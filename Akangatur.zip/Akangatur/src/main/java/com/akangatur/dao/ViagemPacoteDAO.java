package com.akangatur.dao;

import com.akangatur.domain.ViagemPacote;

public class ViagemPacoteDAO extends GenericDAO<ViagemPacote>  {

}
