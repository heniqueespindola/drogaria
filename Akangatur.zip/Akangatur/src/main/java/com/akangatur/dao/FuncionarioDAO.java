package com.akangatur.dao;

import com.akangatur.domain.Funcionario;
import com.akangatur.dao.GenericDAO;

public class FuncionarioDAO extends GenericDAO<Funcionario> {

}
