package com.akangatur.dao;

import com.akangatur.domain.Cliente;
import com.akangatur.dao.GenericDAO;

public class ClienteDAO extends GenericDAO<Cliente>{

}
