package com.akangatur.dao;

import com.akangatur.domain.ItemVenda;
import com.akangatur.dao.GenericDAO;

public class ItemVendaDAO extends GenericDAO<ItemVenda> {

}
