package com.akangatur.dao;

import com.akangatur.domain.Usuario;

public class UsuarioDAO extends GenericDAO<Usuario> {

}
