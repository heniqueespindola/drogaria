package com.akangatur.dao;

import com.akangatur.domain.Venda;

public class VendaDAO extends GenericDAO<Venda>  {

}
