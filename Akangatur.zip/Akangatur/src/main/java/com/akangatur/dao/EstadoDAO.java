package com.akangatur.dao;

import com.akangatur.domain.Estado;
import com.akangatur.dao.GenericDAO;

public class EstadoDAO extends GenericDAO<Estado>{

}
