package com.akangatur.dao;

import com.akangatur.dao.GenericDAO;
import com.akangatur.domain.Cidade;

public class CidadeDAO extends GenericDAO<Cidade>{

}
