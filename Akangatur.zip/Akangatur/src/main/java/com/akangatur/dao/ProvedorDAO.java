package com.akangatur.dao;

import com.akangatur.domain.Provedor;

public class ProvedorDAO extends GenericDAO<Provedor> {

}
