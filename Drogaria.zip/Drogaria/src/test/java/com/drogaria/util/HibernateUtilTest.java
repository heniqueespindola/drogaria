package com.drogaria.util;
/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
import org.hibernate.Session;
import org.junit.Test;

public class HibernateUtilTest {

	public static void main(final String[] args) {
		final Session sessao = HibernateUtil.getFabricaDeSessoes()
				.openSession();
		sessao.close();
		HibernateUtil.getFabricaDeSessoes().close();
	}

	@Test
	public void conectar() {
		final Session sessao = HibernateUtil.getFabricaDeSessoes()
				.openSession();
		sessao.close();
		HibernateUtil.getFabricaDeSessoes().close();
	}
}
