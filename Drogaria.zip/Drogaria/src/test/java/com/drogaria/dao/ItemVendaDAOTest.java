/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Funcionario;
import com.drogaria.domain.ItemVenda;
import com.drogaria.domain.Produto;

public class ItemVendaDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Long codigoFuncionario = 1L;
		final Long codigoProduto = 1L;

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO
				.buscar(codigoFuncionario);

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final Produto produto = produtoDAO.buscar(codigoProduto);

		final ItemVenda itemVenda = new ItemVenda();

		itemVenda.setPrecoParcial(new BigDecimal("32.65"));
		itemVenda.setProduto(produto);
		itemVenda.setQuantidade(new Short("6"));
		itemVenda.setFuncionario(funcionario);

		final ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
		itemVendaDAO.salvar(itemVenda);
	}

	@Test
	@Ignore
	public void listar() {
		final ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
		final List<ItemVenda> resultado = itemVendaDAO.listar();

		if (resultado == null) {
			System.out.println("Nenhum registro Encontrado");
		} else {
			for (final ItemVenda itemVenda : resultado) {
				System.out.println("Codigo: " + itemVenda.getCodigo());
				System.out.println("Quantidade: " + itemVenda.getQuantidade());
				System.out.println("nome Funcionário: "
						+ itemVenda.getFuncionario().getPessoa().getNome());
				System.out.println("Preço Parcial: "
						+ itemVenda.getPrecoParcial());
				System.out.println("Descrição do Produto: "
						+ itemVenda.getProduto().getDescricao());
			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;
		final ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
		final ItemVenda itemVenda = itemVendaDAO.buscar(codigo);

		if (itemVenda == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			System.out.println("Codigo: " + itemVenda.getCodigo());
			System.out.println("Quantidade: " + itemVenda.getQuantidade());
			System.out.println("nome Funcionário: "
					+ itemVenda.getFuncionario().getPessoa().getNome());
			System.out.println("Preço Parcial: " + itemVenda.getPrecoParcial());
			System.out.println("Descrição do Produto: "
					+ itemVenda.getProduto().getDescricao());
		}
	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 1L;
		final ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
		final ItemVenda itemVenda = itemVendaDAO.buscar(codigo);

		if (itemVenda == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			itemVendaDAO.excluir(itemVenda);
			System.out.println("Dados que foram excluidos");
			System.out.println("Codigo: " + itemVenda.getCodigo());
			System.out.println("Descrição do Produto: "
					+ itemVenda.getProduto().getDescricao());
		}
	}

	public void editar() {
		final Long codigoFuncionario = 2L;
		final Long codigoProduto = 2L;
		final Long codigo = 2L;

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO
				.buscar(codigoFuncionario);

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final Produto produto = produtoDAO.buscar(codigoProduto);

		final ItemVendaDAO itemVendaDAO = new ItemVendaDAO();
		final ItemVenda itemVenda = itemVendaDAO.buscar(codigo);

		if (itemVenda == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			itemVenda.setPrecoParcial(new BigDecimal("32.65"));
			itemVenda.setProduto(produto);
			itemVenda.setQuantidade(new Short("5"));
			itemVenda.setFuncionario(funcionario);

			itemVendaDAO.editar(itemVenda);
		}

	}

}
