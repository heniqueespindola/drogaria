/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Fabricante;

public class FabricanteDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Fabricante fabricante = new Fabricante();

		fabricante.setDescricao("oi");

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		fabricanteDAO.salvar(fabricante);

	}

	@Test
	@Ignore
	public void listar() {
		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final List<Fabricante> resultado = fabricanteDAO.listar();

		for (final Fabricante fabricante : resultado) {
			System.out.println(fabricante.getDescricao());
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 2L;
		/** esse é a notação do numero 2 em Long **/

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final Fabricante fabricante = fabricanteDAO.buscar(codigo);

		if (fabricante == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			System.out.println("Registro Encontrado");
			System.out.println(fabricante.getDescricao());
		}

	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 8L;
		/** esse é o codigo de quem quer excluir **/

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final Fabricante fabricante = fabricanteDAO.buscar(codigo);
		if (fabricante == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			fabricanteDAO.excluir(fabricante);
			System.out.println("Registro Removido");
			System.out.println(fabricante.getDescricao());
		}

	}

	@Test
	@Ignore
	public void editar() {
		final Long codigo = 10L;
		/** esse é o codigo de quem quer excluir **/

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final Fabricante fabricante = fabricanteDAO.buscar(codigo);

		if (fabricante == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			System.out.println("Registro Editado - Antes");
			System.out.println(fabricante.getDescricao());

			fabricante.setDescricao("Diga qualquer coisa");
			fabricanteDAO.editar(fabricante);

			System.out.println("Registro Editado");
			System.out.println(fabricante.getDescricao());
		}
	}
	
	@Test
	@Ignore
	public void merge() {
		//final Fabricante fabricante = new Fabricante();
		//fabricante.setDescricao("Fabricante A");

		//final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		//fabricanteDAO.merge(fabricante);
		
		FabricanteDAO fabricanteDAO = new FabricanteDAO();
		Fabricante fabricante = fabricanteDAO.buscar(5L);
		fabricante.setDescricao("Fabricante B");
		fabricanteDAO.merge(fabricante);
	}

}
