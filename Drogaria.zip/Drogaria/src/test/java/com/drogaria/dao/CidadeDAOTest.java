/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Cidade;
import com.drogaria.domain.Estado;

public class CidadeDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Long codigoEstado = 1L;
		final EstadoDAO estadoDAO = new EstadoDAO();

		final Estado estado = estadoDAO.buscar(codigoEstado);

		final Cidade cidade = new Cidade();
		cidade.setNome("Durinhos");
		cidade.setEstado(estado);

		final CidadeDAO cidadeDAO = new CidadeDAO();
		cidadeDAO.salvar(cidade);

	}

	@Test
	@Ignore
	public void listar() {
		final CidadeDAO cidadeDAO = new CidadeDAO();
		final List<Cidade> resultado = cidadeDAO.listar();

		for (final Cidade cidade : resultado) {

			System.out.println("Codigo : " + cidade.getCodigo());
			System.out.println("Nome da Cidade : " + cidade.getNome());
			System.out.println("Codigo do Estado : "
					+ cidade.getEstado().getCodigo());
			System.out.println("Sigla do Estado : "
					+ cidade.getEstado().getSigla());
			System.out.println("Nome do Estado : "
					+ cidade.getEstado().getNome());
			System.out.println();
		}

	}

	@Test
	@Ignore
	public void buscar() {

		final Long codigo = 3L;
		final CidadeDAO cidadeDAO = new CidadeDAO();
		final Cidade cidade = cidadeDAO.buscar(codigo);

		if (cidade == null) {

			System.out.println("Nenhum resgistro encontrado");

		} else {

			System.out.println("Codigo : " + cidade.getCodigo());
			System.out.println("Nome da Cidade : " + cidade.getNome());
			System.out.println("Codigo do Estado : "
					+ cidade.getEstado().getCodigo());
			System.out.println("Sigla do Estado : "
					+ cidade.getEstado().getSigla());
			System.out.println("Nome do Estado : "
					+ cidade.getEstado().getNome());
		}
	}

	@Test
	public void excluir() {
		final Long codigo = 1L;

		final CidadeDAO cidadeDAO = new CidadeDAO();
		final Cidade cidade = cidadeDAO.buscar(codigo);

		if (cidade == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			cidadeDAO.excluir(cidade);
			System.out.println("Cidade Removida");
			System.out.println("Codigo : " + cidade.getCodigo());
			System.out.println("Nome da Cidade : " + cidade.getNome());
			System.out.println("Codigo do Estado : "
					+ cidade.getEstado().getCodigo());
			System.out.println("Sigla do Estado : "
					+ cidade.getEstado().getSigla());
			System.out.println("Nome do Estado : "
					+ cidade.getEstado().getNome());
		}

	}

	@Test
	public void editar() {
		final Long codigoCidade = 10L;
		final Long codigoEstado = 11L;

		final EstadoDAO estadoDAO = new EstadoDAO();
		final Estado estado = estadoDAO.buscar(codigoEstado);

		final CidadeDAO cidadeDAO = new CidadeDAO();
		final Cidade cidade = cidadeDAO.buscar(codigoCidade);

		if (cidade == null || estado == null) {
			System.out.println("Cidade a ser editada");
		} else {
			System.out.println("Codigo : " + cidade.getCodigo());
			System.out.println("Nome da Cidade : " + cidade.getNome());
			System.out.println("Codigo do Estado : "
					+ cidade.getEstado().getCodigo());
			System.out.println("Sigla do Estado : "
					+ cidade.getEstado().getSigla());
			System.out.println("Nome do Estado : "
					+ cidade.getEstado().getNome());

			cidade.setNome("Rio Grande");
			cidade.setEstado(estado);

			cidadeDAO.editar(cidade);

			System.out.println("Codigo : " + cidade.getCodigo());
			System.out.println("Nome da Cidade : " + cidade.getNome());
			System.out.println("Codigo do Estado : "
					+ cidade.getEstado().getCodigo());
			System.out.println("Sigla do Estado : "
					+ cidade.getEstado().getSigla());
			System.out.println("Nome do Estado : "
					+ cidade.getEstado().getNome());

		}
	}

}
