/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Cliente;
import com.drogaria.domain.Funcionario;
import com.drogaria.domain.Venda;

public class VendaDAOTest {

	@Test
	@Ignore
	public void salvar() throws ParseException {
		final Long codigoFuncionario = 1L;
		final Long codigoCliente = 1L;

		final Venda venda = new Venda();
		final Date date = new Date();

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO
				.buscar(codigoFuncionario);

		final ClienteDAO clienteDAO = new ClienteDAO();
		final Cliente cliente = clienteDAO.buscar(codigoCliente);

		venda.setHorario((java.sql.Date) date);

		venda.setPrecoTotal(new BigDecimal("16.58"));
		venda.setCliente(cliente);
		venda.setFuncionario(funcionario);

		final VendaDAO vendaDAO = new VendaDAO();

		vendaDAO.salvar(venda);

	}

	@Test
	@Ignore
	public void listar() {
		final VendaDAO vendaDAO = new VendaDAO();
		final List<Venda> resultado = vendaDAO.listar();

		if (resultado == null) {
			System.out.println("Nenhum Registro Cadastrado");
		} else {

			for (final Venda venda : resultado) {
				System.out.println("Dia: " + venda.getHorario());
				System.out.println("Preço: " + venda.getPrecoTotal());
				System.out.println("Nome Funcionario: "
						+ venda.getFuncionario().getPessoa().getNome());
				System.out.println("Nome do Comprador: "
						+ venda.getCliente().getPessoa().getNome());
			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;

		final VendaDAO vendaDAO = new VendaDAO();
		final Venda venda = vendaDAO.buscar(codigo);

		if (venda == null) {
			System.out.println("Registro não encontrado");
		} else {
			System.out.println("Dia: " + venda.getHorario());
			System.out.println("Preço: " + venda.getPrecoTotal());
			System.out.println("Nome Funcionario: "
					+ venda.getFuncionario().getPessoa().getNome());
			System.out.println("Nome do Comprador: "
					+ venda.getCliente().getPessoa().getNome());
		}

	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 1L;

		final VendaDAO vendaDAO = new VendaDAO();
		final Venda venda = vendaDAO.buscar(codigo);

		if (venda == null) {
			System.out.println("Registro não encontrado");
		} else {
			vendaDAO.excluir(venda);
			System.out.println("Venda excluida");
			System.out.println("Dia: " + venda.getHorario());
			System.out.println("Preço: " + venda.getPrecoTotal());
			System.out.println("Nome Funcionario: "
					+ venda.getFuncionario().getPessoa().getNome());
			System.out.println("Nome do Comprador: "
					+ venda.getCliente().getPessoa().getNome());
		}
	}

	@Test
	@Ignore
	public void editar() {
		final Long codigoFuncionario = 1L;
		final Long codigoCliente = 1L;
		final Long codigo = 1L;
		final Date date = new Date();

		final VendaDAO vendaDAO = new VendaDAO();
		final Venda venda = vendaDAO.buscar(codigo);

		final ClienteDAO clienteDAO = new ClienteDAO();
		final Cliente cliente = clienteDAO.buscar(codigoCliente);

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO
				.buscar(codigoFuncionario);

		if (venda == null) {
			System.out.println("Registro não encontrado");
		} else {

			venda.setHorario((java.sql.Date) date);
			venda.setPrecoTotal(new BigDecimal("16.54"));
			venda.setCliente(cliente);
			venda.setFuncionario(funcionario);

			vendaDAO.editar(venda);
		}

	}

}
