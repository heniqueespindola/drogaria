/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Cliente;
import com.drogaria.domain.Pessoa;

public class ClienteDAOTest {

	@Test
	@Ignore
	public void salvar() throws ParseException {
		final Cliente cliente = new Cliente();
		final Long codigo = 1L;

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		// hora do sistema new Date() or
		// new SimpleDateFormat("dd/MM/yyyy").parse("09/06/2016")

		cliente.setDataCadastro(new SimpleDateFormat("dd/MM/yyyy")
				.parse("09/06/2016"));
		cliente.setLiberado(true);/* false or true */
		cliente.setPessoa(pessoa);

		final ClienteDAO clienteDAO = new ClienteDAO();
		clienteDAO.salvar(cliente);

	}

	@Test
	@Ignore
	public void listar() {
		final ClienteDAO clienteDAO = new ClienteDAO();
		final List<Cliente> resultado = clienteDAO.listar();

		if (resultado == null) {
			System.out.println("Registro não Encontrado");
		} else {
			for (final Cliente cliente : resultado) {
				System.out.println("Codigo: " + cliente.getCodigo());
				System.out.println("Nome do Cliente: "
						+ cliente.getPessoa().getNome());
				System.out.println("Data de Cadastro: "
						+ cliente.getDataCadastro());
				System.out.println("Status do Cliente: "
						+ cliente.getLiberado());
			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;
		final ClienteDAO clienteDAO = new ClienteDAO();
		final Cliente cliente = clienteDAO.buscar(codigo);

		if (cliente == null) {
			System.out.println("Registro não Encontrado");
		} else {
			System.out.println("Codigo: " + cliente.getCodigo());
			System.out.println("Nome do Cliente: "
					+ cliente.getPessoa().getNome());
			System.out
					.println("Data de Cadastro: " + cliente.getDataCadastro());
			System.out.println("Status do Cliente: " + cliente.getLiberado());
		}
	}

	@Test
	@Ignore
	public void excluir() {

		final Long codigo = 1L;

		final ClienteDAO clienteDAO = new ClienteDAO();
		final Cliente cliente = clienteDAO.buscar(codigo);

		if (cliente == null) {
			System.out.println("Registro não Encontrado");
		} else {
			System.out.println("Codigo: " + cliente.getCodigo());
			System.out.println("Nome do Cliente: "
					+ cliente.getPessoa().getNome());

			clienteDAO.excluir(cliente);

			System.out.println("Registro excluido com Sucesso");
		}
	}

	@Test
	@Ignore
	public void editar() throws ParseException {
		final Long codigoCliente = 1L;
		final Long codigoPessoa = 1L;

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigoPessoa);

		final ClienteDAO clienteDAO = new ClienteDAO();
		final Cliente cliente = clienteDAO.buscar(codigoCliente);

		if (pessoa == null || cliente == null) {
			System.out.println("Registro não Encontrado");
		} else {
			cliente.setDataCadastro(new SimpleDateFormat("dd/MM/yyyy")
					.parse("10/09/2015"));
			cliente.setLiberado(false);/* false or true */
			cliente.setPessoa(pessoa);

			clienteDAO.editar(cliente);
		}
	}

}
