/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.math.BigDecimal;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Fabricante;
import com.drogaria.domain.Produto;

public class ProdutoDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Long codigoFabricante = 1L;

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final Fabricante fabricante = fabricanteDAO.buscar(codigoFabricante);

		final Produto produto = new Produto();
		produto.setDescricao("hahaha");
		produto.setPreco(new BigDecimal("13.70"));
		produto.setQuantidade(new Short("7"));
		produto.setFabricante(fabricante);

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		produtoDAO.salvar(produto);
	}

	@Test
	@Ignore
	public void listar() {

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final List<Produto> resultado = produtoDAO.listar();

		if (resultado == null) {
			System.out.println("Sem registros cadastrados");
		} else {

			System.out.println();
			for (final Produto produto : resultado) {

				System.out.println("Código : " + produto.getCodigo());
				System.out.println("Descrição : " + produto.getDescricao());
				System.out.println("Codigo do Fabricante : "
						+ produto.getFabricante().getCodigo());
				System.out.println("Descrição do Fabricante : "
						+ produto.getFabricante().getDescricao());
				System.out.println("Quantidade : " + produto.getQuantidade());
				System.out.println("Preço : " + produto.getPreco());
				System.out.println();
			}
		}

	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final Produto produto = produtoDAO.buscar(codigo);

		if (produto == null) {
			System.out.println("Nenhum Registro Encontrado");
		} else {

			System.out.println("Código : " + produto.getCodigo());
			System.out.println("Descrição : " + produto.getDescricao());
			System.out.println("Codigo do Fabricante : "
					+ produto.getFabricante().getCodigo());
			System.out.println("Descrição do Fabricante : "
					+ produto.getFabricante().getDescricao());
			System.out.println("Quantidade : " + produto.getQuantidade());
			System.out.println("Preço : " + produto.getPreco());
			System.out.println();
		}

	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 1L;

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final Produto produto = produtoDAO.buscar(codigo);

		if (produto == null) {
			System.out.println("Nenhum Registro Encontrando");
		} else {

			produtoDAO.excluir(produto);

			System.out.println("Produto excluido");
			System.out.println("Código : " + produto.getCodigo());
			System.out.println("Descrição : " + produto.getDescricao());
			System.out.println("Codigo do Fabricante : "
					+ produto.getFabricante().getCodigo());
			System.out.println("Descrição do Fabricante : "
					+ produto.getFabricante().getDescricao());
			System.out.println("Quantidade : " + produto.getQuantidade());
			System.out.println("Preço : " + produto.getPreco());
			System.out.println();

		}

	}

	@Test
	@Ignore
	public void editar() {
		final Long codigoFabricante = 1L;
		final Long codigoProduto = 1L;

		final FabricanteDAO fabricanteDAO = new FabricanteDAO();
		final Fabricante fabricante = fabricanteDAO.buscar(codigoFabricante);

		final ProdutoDAO produtoDAO = new ProdutoDAO();
		final Produto produto = produtoDAO.buscar(codigoProduto);

		if (produto == null || fabricante == null) {
			System.out.println("Nenhum Registro Encontrado");
		} else {

			// System.ou.println dos dados

			produto.setDescricao("nova descrição");
			produto.setFabricante(fabricante);
			produto.setPreco(new BigDecimal("15.65"));
			produto.setQuantidade(new Short("9"));
		}

	}

}
