/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.text.ParseException;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Pessoa;
import com.drogaria.domain.Usuario;

public class UsuarioDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Usuario usuario = new Usuario();
		final Long codigo = 1L;

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		usuario.setAtivo(true);/* false or true */
		usuario.setPessoa(pessoa);
		usuario.setSenha("Foiomhjbb");
		usuario.setTipo('A');

		final UsuarioDAO usuarioDAO = new UsuarioDAO();
		usuarioDAO.salvar(usuario);

	}

	@Test
	@Ignore
	public void listar() {
		final UsuarioDAO usuarioDAO = new UsuarioDAO();
		final List<Usuario> resultado = usuarioDAO.listar();

		if (resultado == null) {
			System.out.println("Registro não Encontrado");
		} else {
			for (final Usuario usuario : resultado) {
				System.out.println("Codigo: " + usuario.getCodigo());
				System.out.println("Nome: " + usuario.getPessoa().getNome());
				System.out.println("Tipo: " + usuario.getTipo());
				System.out.println("Status: " + usuario.getAtivo());

			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;
		final UsuarioDAO usuarioDAO = new UsuarioDAO();
		final Usuario usuario = usuarioDAO.buscar(codigo);

		if (usuario == null) {
			System.out.println("Registro não Encontrado");
		} else {
			System.out.println("Codigo: " + usuario.getCodigo());
			System.out.println("Nome: " + usuario.getPessoa().getNome());
			System.out.println("Tipo: " + usuario.getTipo());
			System.out.println("Status: " + usuario.getAtivo());
		}
	}

	@Test
	@Ignore
	public void excluir() {

		final Long codigo = 1L;
		final UsuarioDAO usuarioDAO = new UsuarioDAO();
		final Usuario usuario = usuarioDAO.buscar(codigo);
		if (usuario == null) {
			System.out.println("Registro não Encontrado");
		} else {
			usuarioDAO.excluir(usuario);
			System.out.println("Registro excluido");
			System.out.println("Codigo: " + usuario.getCodigo());
			System.out.println("Nome: " + usuario.getPessoa().getNome());

			System.out.println("Registro excluido com Sucesso");
		}
	}

	@Test
	@Ignore
	public void editar() throws ParseException {
		final Long codigo = 1L;
		final Long codigoPessoa = 1L;

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigoPessoa);

		final UsuarioDAO usuarioDAO = new UsuarioDAO();
		final Usuario usuario = usuarioDAO.buscar(codigo);

		if (usuario == null) {
			System.out.println("Registro não Encontrado");
		} else {
			usuario.setAtivo(false);/* false or true */
			usuario.setPessoa(pessoa);
			usuario.setSenha("Foifgd6fg46");
			usuario.setTipo('B');

			usuarioDAO.editar(usuario);
		}
	}

}
