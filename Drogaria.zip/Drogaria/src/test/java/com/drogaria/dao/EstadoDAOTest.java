/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Estado;

public class EstadoDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Estado estado = new Estado();
		estado.setNome("São Paulo");
		estado.setSigla("SP");

		final EstadoDAO estadoDAO = new EstadoDAO();
		estadoDAO.salvar(estado);
	}

	@Test
	@Ignore
	public void listar() {
		final EstadoDAO estadoDAO = new EstadoDAO();
		final List<Estado> resultado = estadoDAO.listar();

		for (final Estado estado : resultado) {
			System.out.println(estado.getCodigo() + " - " + estado.getSigla()
					+ " - " + estado.getNome());
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 2L;
		/** esse é a notação do numero 2 em Long **/

		final EstadoDAO estadoDAO = new EstadoDAO();
		final Estado estado = estadoDAO.buscar(codigo);

		if (estado == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			System.out.println("Registro Encontrado");
			System.out.println(estado.getCodigo() + " - " + estado.getSigla()
					+ " - " + estado.getNome());
		}

	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 8L;
		/** esse é o codigo de quem quer excluir **/

		final EstadoDAO estadoDAO = new EstadoDAO();
		final Estado estado = estadoDAO.buscar(codigo);
		if (estado == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			estadoDAO.excluir(estado);
			System.out.println("Registro Removido");
			System.out.println(estado.getCodigo() + " - " + estado.getSigla()
					+ " - " + estado.getNome());
		}

	}

	@Test
	public void editar() {
		final Long codigo = 10L;
		/** esse é o codigo de quem quer excluir **/

		final EstadoDAO estadoDAO = new EstadoDAO();
		final Estado estado = estadoDAO.buscar(codigo);

		if (estado == null) {
			System.out.println("Nenhum resgistro encontrado");
		} else {
			System.out.println("Registro Editado - Antes");
			System.out.println(estado.getCodigo() + " - " + estado.getSigla()
					+ " - " + estado.getNome());

			estado.setNome("Santa Catarina");
			estado.setSigla("SC");
			estadoDAO.editar(estado);

			System.out.println("Registro Editado");
			System.out.println(estado.getCodigo() + " - " + estado.getSigla()
					+ " - " + estado.getNome());
		}
	}

}
