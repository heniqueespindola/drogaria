/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Funcionario;
import com.drogaria.domain.Pessoa;

public class FuncionarioDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Long codigo = 1L;
		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		final Funcionario funcionario = new Funcionario();

		funcionario.setCarteiraTrabalho("sei la o que colocar");
		funcionario.setDataAdmissao((java.sql.Date) new Date());
		funcionario.setPessoa(pessoa);

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		funcionarioDAO.salvar(funcionario);
	}

	@Test
	@Ignore
	public void listar() {
		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final List<Funcionario> resultado = funcionarioDAO.listar();

		if (resultado == null) {
			System.out.println("Nenhum registro Encontrado");
		} else {
			for (final Funcionario funcionario : resultado) {
				System.out.println("Codigo: " + funcionario.getCodigo());
				System.out
						.println("Nome: " + funcionario.getPessoa().getNome());
				System.out.println("Data Admissão: "
						+ funcionario.getDataAdmissao());
				System.out.println("Carteira de Trabalho: "
						+ funcionario.getCarteiraTrabalho());
			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;
		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO.buscar(codigo);

		if (funcionario == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			System.out.println("Codigo: " + funcionario.getCodigo());
			System.out.println("Nome: " + funcionario.getPessoa().getNome());
			System.out.println("Data Admissão: "
					+ funcionario.getDataAdmissao());
			System.out.println("Carteira de Trabalho: "
					+ funcionario.getCarteiraTrabalho());
		}
	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 1L;
		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO.buscar(codigo);

		if (funcionario == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			funcionarioDAO.excluir(funcionario);
			System.out.println("Dados que foram excluidos");
			System.out.println("Codigo: " + funcionario.getCodigo());
			System.out.println("Nome: " + funcionario.getPessoa().getNome());
		}
	}

	public void editar() {
		final Long codigoFuncionario = 1L;
		final Long codigo = 1L;

		final FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		final Funcionario funcionario = funcionarioDAO
				.buscar(codigoFuncionario);

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		if (funcionario == null) {
			System.out.println("Nenhum registro encontrado");
		} else {
			funcionario.setCarteiraTrabalho("sei la");
			funcionario.setDataAdmissao((java.sql.Date) new Date());
			funcionario.setPessoa(pessoa);

			funcionarioDAO.editar(funcionario);
		}

	}

}
