/**
 * Copyright (c) 2016  Brasilcap - www.brasilcap.com.br
 * Todos os direitos reservados.
 * 
 * NÃO ALTERE OU REMOVA AS INFORMAÇÕES DE COPYRIGHT
 * OU AS INFORMAÇÕES CONTIDAS NESTE HEADER
 * 
 * Este código-fonte é de propriedade da Brasilcap Capitalizações S.A.
 * e não pode ser copiado, modificado ou compartilhado sem autorização 
 * prévia, estando sujeito a penalidades judiciais caso ocorra.
 * 
 */
package com.drogaria.dao;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.drogaria.domain.Cidade;
import com.drogaria.domain.Pessoa;

public class PessoaDAOTest {

	@Test
	@Ignore
	public void salvar() {
		final Long codigo = 1L;
		final CidadeDAO cidadeDAO = new CidadeDAO();
		final Cidade cidade = cidadeDAO.buscar(codigo);

		final Pessoa pessoa = new Pessoa();

		pessoa.setBairro("Rio de Janeiro");
		pessoa.setCelular("(21) 11111-1111");
		pessoa.setCep("21222-211");
		pessoa.setComplemento("sem complementos");
		pessoa.setCpf("123456789");
		pessoa.setEmail("alguma.coisa@gmail.com");
		pessoa.setNome("Zé");
		pessoa.setNumero(new Short("102"));
		pessoa.setRg("29.965.965-9");
		pessoa.setRua("Avenida Chile");
		pessoa.setTelefone("(21) 3569-6598");
		pessoa.setCidade(cidade);

		final PessoaDAO pessoaDAO = new PessoaDAO();

		pessoaDAO.salvar(pessoa);

		System.out.println("Dados salvos com sucesso");

	}

	@Test
	@Ignore
	public void listar() {
		final PessoaDAO pessoaDAO = new PessoaDAO();
		final List<Pessoa> resultado = pessoaDAO.listar();

		if (resultado == null) {
			System.out.println("Registro não encontrado");
		} else {
			for (final Pessoa pessoa : resultado) {
				System.out.println("Código : " + pessoa.getCodigo());
				System.out.println("Nome : " + pessoa.getNome());
				System.out.println("Bairro : " + pessoa.getBairro());
				System.out.println("Celular : " + pessoa.getCelular());
				System.out.println("Cep : " + pessoa.getCep());
				System.out.println("Codigo da Cidade : "
						+ pessoa.getCidade().getCodigo());
				System.out.println("Cidade : " + pessoa.getCidade().getNome());
				System.out.println("Codigo do Estado : "
						+ pessoa.getCidade().getEstado().getCodigo());
				System.out.println("Estado : "
						+ pessoa.getCidade().getEstado().getNome());
				System.out.println("Sigla do Estado : "
						+ pessoa.getCidade().getEstado().getSigla());
				System.out.println("Complemento : " + pessoa.getComplemento());
				System.out.println("Cpf : " + pessoa.getCpf());
				System.out.println("Email : " + pessoa.getEmail());
				System.out.println("Numero : " + pessoa.getNumero());
				System.out.println("Rg : " + pessoa.getRg());
				System.out.println("Rua : " + pessoa.getRua());
				System.out.println("Telefone : " + pessoa.getTelefone());

			}
		}
	}

	@Test
	@Ignore
	public void buscar() {
		final Long codigo = 1L;
		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		if (pessoa == null) {
			System.out.println("resgistro não Encontrado");
		} else {
			System.out.println("Código : " + pessoa.getCodigo());
			System.out.println("Nome : " + pessoa.getNome());
			System.out.println("Bairro : " + pessoa.getBairro());
			System.out.println("Celular : " + pessoa.getCelular());
			System.out.println("Cep : " + pessoa.getCep());
			System.out.println("Codigo da Cidade : "
					+ pessoa.getCidade().getCodigo());
			System.out.println("Cidade : " + pessoa.getCidade().getNome());
			System.out.println("Codigo do Estado : "
					+ pessoa.getCidade().getEstado().getCodigo());
			System.out.println("Estado : "
					+ pessoa.getCidade().getEstado().getNome());
			System.out.println("Sigla do Estado : "
					+ pessoa.getCidade().getEstado().getSigla());
			System.out.println("Complemento : " + pessoa.getComplemento());
			System.out.println("Cpf : " + pessoa.getCpf());
			System.out.println("Email : " + pessoa.getEmail());
			System.out.println("Numero : " + pessoa.getNumero());
			System.out.println("Rg : " + pessoa.getRg());
			System.out.println("Rua : " + pessoa.getRua());
			System.out.println("Telefone : " + pessoa.getTelefone());

		}
	}

	@Test
	@Ignore
	public void excluir() {
		final Long codigo = 1L;
		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigo);

		if (pessoa == null) {
			System.out.println("Registro não encontrado");
		} else {
			System.out.println("Dados a serem excluidos");
			System.out.println("Código : " + pessoa.getCodigo());
			System.out.println("Nome : " + pessoa.getNome());

			pessoaDAO.excluir(pessoa);

			System.out.println("Dados excluidos com sucesso");

		}
	}

	@Test
	@Ignore
	public void editar() {
		final Long codigoCidade = 1L;
		final Long codigoPessoa = 1L;

		final CidadeDAO cidadeDAO = new CidadeDAO();
		final Cidade cidade = cidadeDAO.buscar(codigoCidade);

		final PessoaDAO pessoaDAO = new PessoaDAO();
		final Pessoa pessoa = pessoaDAO.buscar(codigoPessoa);

		if (cidade == null || pessoa == null) {
			System.out.println("Registro não Encontrado");
		} else {
			pessoa.setBairro("Rio de Jan");
			pessoa.setCelular("(21) 11111-1");
			pessoa.setCep("21222-");
			pessoa.setComplemento("sem complemes");
			pessoa.setCpf("123456");
			pessoa.setEmail("alguma.coisa@");
			pessoa.setNome("Maze");
			pessoa.setNumero(new Short("1"));
			pessoa.setRg("29.965.");
			pessoa.setRua("Avenida");
			pessoa.setTelefone("(21) 3569");
			pessoa.setCidade(cidade);

			pessoaDAO.editar(pessoa);
		}
	}

}
