package com.drogaria.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.drogaria.dao.ClienteDAO;
import com.drogaria.dao.FuncionarioDAO;
import com.drogaria.dao.VendaDAO;
import com.drogaria.domain.Cliente;
import com.drogaria.domain.Funcionario;
import com.drogaria.domain.Venda;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class VendaBean implements Serializable {
	Venda venda;
	List<Venda> vendas;
	List<Cliente> clientes;
	List<Funcionario> funcionarios;
	
	public Venda getVenda() {
		return venda;
	}
	public void setVenda(Venda venda) {
		this.venda = venda;
	}
	
	public List<Venda> getVendas() {
		return vendas;
	}
	public void setVendas(List<Venda> vendas) {
		this.vendas = vendas;
	}
	
	public void novo(){
		try{
			
			venda = new Venda();
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			ClienteDAO clienteDAO = new ClienteDAO();
			
			funcionarios = funcionarioDAO.listar();
			clientes = clienteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao tentar inicializar Venda");
			erro.printStackTrace();
		}
	}
	
	@PostConstruct
	public void listar(){
		try{
			VendaDAO vendaDAO = new VendaDAO();
			vendas = vendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar listar Vendas");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try{
			VendaDAO vendaDAO = new VendaDAO();
			vendaDAO.merge(venda);
			
			novo();
			vendas = vendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar salvar Venda");
			erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		venda = (Venda) evento.getComponent().getAttributes().get("vendaSelecionada");
		try{
			VendaDAO vendaDAO = new VendaDAO();
			vendaDAO.excluir(venda);
			
			novo();
			vendas = vendaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar excluir Venda");
			erro.printStackTrace();
		}
		
	}
	
	public void editar(ActionEvent evento){
		try{
			
			venda = (Venda) evento.getComponent().getAttributes().get("vendaSelecionada");
			FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
			ClienteDAO clienteDAO = new ClienteDAO();
			
			funcionarios = funcionarioDAO.listar();
			clientes = clienteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao editar Venda");
			erro.printStackTrace();
		}
	}

}
