package com.drogaria.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.drogaria.dao.FabricanteDAO;
import com.drogaria.dao.ProdutoDAO;
import com.drogaria.domain.Fabricante;
import com.drogaria.domain.Produto;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class ProdutoBean implements Serializable{
	Produto produto;
	List<Produto> produtos;
	List<Fabricante> fabricantes;
	
	public Produto getProduto() {
		return produto;
	}
	public void setProduto(Produto produto) {
		this.produto = produto;
	}
	
	public List<Produto> getProdutos() {
		return produtos;
	}
	public void setProdutos(List<Produto> produtos) {
		this.produtos = produtos;
	}
	
	public void novo(){
		try{
			produto = new Produto();
			
			FabricanteDAO fabricanteDAO = new FabricanteDAO();
			fabricantes = fabricanteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar inicializar Produto");
			erro.printStackTrace();
		}
	}
	
	@PostConstruct
	public void listar(){
		try{
			ProdutoDAO produtoDAO = new ProdutoDAO();
			produtos = produtoDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar listar Produto");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try{
			ProdutoDAO produtoDAO = new ProdutoDAO();
			produtoDAO.merge(produto);
			
			novo();
			produtos = produtoDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar salvar Produto");
			erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		produto = (Produto) evento.getComponent().getAttributes().get("produtoSelecionado");
		try{
			ProdutoDAO produtoDAO = new ProdutoDAO();
			produtoDAO.excluir(produto);
			
			novo();
			produtos = produtoDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar excluir Produtos");
			erro.printStackTrace();
		}
	}
	
	public void editar(ActionEvent evento){
		try{
			produto = (Produto) evento.getComponent().getAttributes().get("produtoSelecionado");
			
			FabricanteDAO fabricanteDAO = new FabricanteDAO();
			fabricantes = fabricanteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar editar Produto");
			erro.printStackTrace();
		}
	}

}
