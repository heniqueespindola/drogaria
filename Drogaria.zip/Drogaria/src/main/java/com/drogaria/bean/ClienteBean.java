package com.drogaria.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.drogaria.dao.ClienteDAO;
import com.drogaria.dao.PessoaDAO;
import com.drogaria.domain.Cliente;
import com.drogaria.domain.Pessoa;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class ClienteBean implements Serializable{
	
	Cliente cliente;
	List<Cliente> clientes;
	List<Pessoa> pessoas;
	
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public List<Cliente> getClientes() {
		return clientes;
	}
	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}
	
	public void novo(){
		try{
			cliente = new Cliente();
			
			PessoaDAO pessoaDAO = new PessoaDAO();
			
			pessoas = pessoaDAO.listar();
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao inicializar Cliente");
			erro.printStackTrace();
		}
		
	}
	
	@PostConstruct
	public void listar(){
		try{
			ClienteDAO clienteDAO = new ClienteDAO();
			clientes = clienteDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Aconteceu um erro ao listar Cliente");
			erro.printStackTrace();
			
		}
	}
	
	
	public void salvar(){
		try{
			ClienteDAO clienteDAO = new ClienteDAO();
			clienteDAO.merge(cliente);
			
			novo();
			clienteDAO.listar();
			
			
			Messages.addGlobalInfo("Cliente: " +cliente.getPessoa().getNome() + " salvo com sucesso");
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Aconteceu um erro ao salvar Cliente");
			erro.printStackTrace();
			
		}
	}
	
	public void excluir(ActionEvent evento){
		cliente = (Cliente) evento.getComponent().getAttributes().get("clienteSelecionado");
		try{
			ClienteDAO clienteDAO = new ClienteDAO();
			clienteDAO.excluir(cliente);
			
			novo();
			clientes = clienteDAO.listar();
			
			
			Messages.addGlobalInfo("Cliente: " +cliente.getPessoa().getNome() + " salvo com sucesso");
		}catch( RuntimeException erro ){
			Messages.addGlobalError("Aconteceu um erro ao excluir Cliente");
			erro.printStackTrace();
		}
		
	}
	
	public void editar( ActionEvent evento ){
		try{
			cliente = (Cliente) evento.getComponent().getAttributes().get("clienteSelecionado");
			
			PessoaDAO pessoaDAO = new PessoaDAO();
			
			pessoas = pessoaDAO.listar();
		}catch(RuntimeException erro){
			Messages.addGlobalError("Ocorreu um erro ao editar Cliente");
			erro.printStackTrace();
		}
		
	}
}
