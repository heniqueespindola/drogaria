package com.drogaria.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.event.ActionEvent;

import org.omnifaces.util.Messages;

import com.drogaria.dao.PessoaDAO;
import com.drogaria.dao.UsuarioDAO;
import com.drogaria.domain.Pessoa;
import com.drogaria.domain.Usuario;

@SuppressWarnings("serial")
@ManagedBean
@ViewScoped
public class UsuarioBean implements Serializable {
	Usuario usuario;
	List<Usuario> usuarios;
	List<Pessoa> pessoas;
	
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	
	public List<Usuario> getUsuarios() {
		return usuarios;
	}
	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	
	public void novo(){
		try{
			usuario = new Usuario();
			
			PessoaDAO pessoaDAO = new PessoaDAO();
			
			pessoas = pessoaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar inicializar Usuário");
			erro.printStackTrace();
		}
	}
	
	@PostConstruct
	public void listar(){
		try{
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarios = usuarioDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar listar Usuario");
			erro.printStackTrace();
		}
	}
	
	public void salvar(){
		try{
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarioDAO.merge(usuario);
			
			novo();
			usuarios = usuarioDAO.listar();
		
		}catch(RuntimeException erro){
		Messages.addGlobalError("Erro ao tentar salvar Usuario");
		erro.printStackTrace();
		}
	}
	
	public void excluir(ActionEvent evento){
		usuario = (Usuario) evento.getComponent().getAttributes().get("usuarioSelecionado");
		try{
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarioDAO.excluir(usuario);
			
			novo();
			usuarios = usuarioDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar excluir Usuario");
			erro.printStackTrace();
		}
	}
	
	public void editar(ActionEvent evento){
		try{
			usuario = (Usuario) evento.getComponent().getAttributes().get("usuarioSelecionado");
			
			PessoaDAO pessoaDAO = new PessoaDAO();
			
			pessoas = pessoaDAO.listar();
			
		}catch(RuntimeException erro){
			Messages.addGlobalError("Erro ao tentar editar Usuário");
			erro.printStackTrace();
		}
	}
	
	
}
