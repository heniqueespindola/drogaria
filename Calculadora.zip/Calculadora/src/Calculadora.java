import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;


@SuppressWarnings("serial")
public class Calculadora extends JFrame implements ActionListener{
	
	JTextField n;
	JLabel t1, t2, t3;
	JButton bt1;
	JFormattedTextField jFormattedTextFieldP1 ; 
	JFormattedTextField jFormattedTextFieldP2 ; 
	JFormattedTextField jFormattedTextFieldP3 ;
	JFormattedTextField jFormattedTextFieldU1 ;
	
	
	
	public Calculadora(){
		
		super("Calculadora");
		setLayout(null);
		
		n = new JTextField();
		t1 = new JLabel("n :");
		t2 = new JLabel("P :");
		t3 = new JLabel("U :");
		
		t1.setBounds(50, 40, 100, 20);
		n.setBounds(70, 40, 30, 20);		
		t2.setBounds(50, 80, 100, 20);
		t3.setBounds(50, 200, 100, 20);
		
		
		bt1 = new JButton("OK");
		bt1.setBounds(100, 240, 100, 20);
		
		MaskFormatter mascP1 = null;
		MaskFormatter mascP2 = null;
		MaskFormatter mascP3 = null;
		MaskFormatter mascU1 = null;
		
		try{
			mascP1 = new MaskFormatter("( #.#### - #.#### - #.#### )");
			mascP2 = new MaskFormatter("( #.#### - #.#### - #.#### )");
			mascP3 = new MaskFormatter("( #.#### - #.#### - #.#### )");
			mascU1 = new MaskFormatter("( #.#### - #.#### - #.#### )");
			
		}catch(ParseException escp){
			System.err.println("Erro na formata��o");
			System.exit(-1);
		}
		
		jFormattedTextFieldP1 = new JFormattedTextField(mascP1);
		jFormattedTextFieldP2 = new JFormattedTextField(mascP2);
		jFormattedTextFieldP3 = new JFormattedTextField(mascP3);
		jFormattedTextFieldU1 = new JFormattedTextField(mascU1);
		jFormattedTextFieldP1.setBounds(70, 80, 180, 20);
		jFormattedTextFieldP2.setBounds(70, 120, 180, 20);
		jFormattedTextFieldP3.setBounds(70, 160, 180, 20);
		jFormattedTextFieldU1.setBounds(70, 200, 180, 20);
		
		
		setSize(300,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		bt1.addActionListener(this);
		
		add(t1);
		add(n);
		
		add(t2);
		add(jFormattedTextFieldP1);
		add(jFormattedTextFieldP2);
		add(jFormattedTextFieldP3);
		
		add(t3);
		add(jFormattedTextFieldU1);
		
		add(bt1);
		
		
	}
	
	
	public static void main(String[] args) {
		Calculadora c = new Calculadora();
		c.setVisible(true);
		
		
	}


	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		Float u1[] = new Float[3];
		Float mat2[][] = new Float[3][3];
		JLabel te1, te2, te3, te4;
		
		if(e.getSource()== bt1){
			
			this.setVisible(false);
			Float mat[][] = new Float[3][3];
			Float mat1[][] = new Float[3][3];
			Float u[] = new Float[3];
			
			
			String text1 = jFormattedTextFieldP1.getText();
			String text2 = jFormattedTextFieldP2.getText();
			String text3 = jFormattedTextFieldP3.getText();
			String text4 = jFormattedTextFieldU1.getText();
			
			//Pega o valor da tela e p�e na matriz
			for(int i = 0; i < 3 ; i++){
				if(i == 0){
					mat1[i][0] = mat[i][0] = Float.valueOf(text1.substring(2, 7)).floatValue();
					mat1[i][1] = mat[i][1] = Float.valueOf(text1.substring(11, 16)).floatValue();
					mat1[i][2] = mat[i][2] = Float.valueOf(text1.substring(20, 25)).floatValue();
				}
				if(i == 1){
					mat1[i][0] = mat[i][0] = Float.valueOf(text2.substring(2, 7)).floatValue();
					mat1[i][1] = mat[i][1] = Float.valueOf(text2.substring(11, 16)).floatValue();
					mat1[i][2] = mat[i][2] = Float.valueOf(text2.substring(20, 25)).floatValue();
				}else{
					mat1[i][0] = mat[i][0] = Float.valueOf(text3.substring(2, 7)).floatValue();
					mat1[i][1] = mat[i][1] = Float.valueOf(text3.substring(11, 16)).floatValue();
					mat1[i][2] = mat[i][2] = Float.valueOf(text3.substring(20, 25)).floatValue();
				}
				
			}
			
			//faz os calculos
			for(int j = 1 ; j < Integer.parseInt(n.getText()) ; j++){
				
				for(int i = 0 ; i < 3 ; i++){
					mat2[i][0] = mat[i][0]*mat1[0][0] + mat[i][1]*mat1[1][0] + mat[i][2]*mat1[2][0];
					mat2[i][1] = mat[i][0]*mat1[0][1] + mat[i][1]*mat1[1][1] + mat[i][2]*mat1[2][1];
					mat2[i][2] = mat[i][0]*mat1[0][2] + mat[i][1]*mat1[1][2] + mat[i][2]*mat1[2][2];
				}
				
				//copia numa terceira matriz para n�o dar problema
				for( int i = 0 ; i < 3 ; i++){
					mat1[i][0] = mat2[i][0];
					mat1[i][1] = mat2[i][1];
					mat1[i][2] = mat2[i][2];
				}
			}
			
			u[0] = Float.valueOf(text4.substring(2, 7)).floatValue();
			u[1] = Float.valueOf(text4.substring(11, 16)).floatValue();
			u[2] = Float.valueOf(text4.substring(20, 25)).floatValue();
			
			u1[0] = u[0]*mat2[0][0] + u[1]*mat2[1][0] + u[2]*mat2[2][0];
			u1[1] = u[0]*mat2[0][1] + u[1]*mat2[1][1] + u[2]*mat2[2][1];
			u1[2] = u[0]*mat2[0][2] + u[1]*mat2[1][2] + u[2]*mat2[2][2];
		}
		
		this.dispose();
		
		JFrame janela1 = new JFrame();
		janela1.setLayout(null);
		
		janela1.setVisible(true);
		
		
		janela1.setSize(400,400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		te1 = new JLabel("P("+n.getText()+") = " + mat2[0][0] +" - "+ mat2[0][1]+" - "+mat2[0][2]);
		te2 = new JLabel("            " + mat2[1][0] +" - "+ mat2[1][1]+" - "+mat2[1][2]);
		te3 = new JLabel("            " + mat2[2][0] +" - "+ mat2[2][1]+" - "+mat2[2][2]);
		te4 = new JLabel("U("+n.getText()+") = {" + u1[0] +" - "+ u1[1]+" - "+u1[2]+ "}");
		
		te1.setBounds(50, 40, 250, 50);			
		te2.setBounds(50, 80, 250, 50);
		te3.setBounds(50, 120, 250, 50);
		te4.setBounds(50, 160, 250, 50);		
		

		janela1.add(te1);
		janela1.add(te2);
		janela1.add(te3);
		janela1.add(te4);

	}
}
